package com.example.demo.gestionSurveillance.salle.dto;

public record SalleDTORequest(
        Boolean disponibilité
    ){
}
