package com.example.demo.gestionSurveillance.emploi.dto;

import java.util.Date;

public record ReqMatiere (int id, String name, Date date, int sessionNumber){}
