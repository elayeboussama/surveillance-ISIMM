package com.example.demo.gestionSurveillance.enseignant;


import com.example.demo.Doa.DepartementRepository;
import com.example.demo.Doa.EnseignantMatiereRepository;
import com.example.demo.Doa.EnseignantRepository;
import com.example.demo.entities.*;
import com.example.demo.gestionSurveillance.emploi.dto.EmploiRequestForGenerating;
import com.example.demo.gestionSurveillance.emploi.dto.ReqMatiere;
import com.example.demo.gestionSurveillance.emploi.dto.Section;
import com.example.demo.gestionSurveillance.enseignant.dto.EnseignantDTORequest;
import com.example.demo.gestionSurveillance.enseignant.dto.EnseignantDTOResponse;
import lombok.RequiredArgsConstructor;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static com.example.demo.gestionSurveillance.enseignant.dto.mapper.EnseignantMappers.mapEnseignantToDTORequest;
import static com.example.demo.gestionSurveillance.enseignant.dto.mapper.EnseignantMappers.mapEnseignantToDTOResponse;

@Service
@RequiredArgsConstructor
public class SurveillanceEnseignantService {

    @Autowired
    private DepartementRepository departementRepository;
    @Autowired
    private EnseignantRepository enseignantRepository;

   public List<EnseignantDTOResponse> findAllEnsignantService(){
       List<Enseignant> enseignants = enseignantRepository.findAll();;


       List<EnseignantDTOResponse> enseignantDTOResponses = new ArrayList<>() ;
       for (Enseignant enseignant : enseignants) {
           EnseignantDTOResponse enseignantDTOResponse = mapEnseignantToDTOResponse(enseignant);
           enseignantDTOResponses.add(enseignantDTOResponse);
       }
       return enseignantDTOResponses;
   }

   public void insertEnseignantService(EnseignantDTORequest enseignantRequest){
       System.out.println("ccccccccccccccccccccc");

       Enseignant enseignant = mapEnseignantToDTORequest(enseignantRequest, departementRepository);
       enseignantRepository.save(enseignant);
   }



   public ResponseEntity<String> deleteEnseignantService(Long id){
       Optional<Enseignant> enseignants  = enseignantRepository.findById(id);

       if (enseignants.isPresent()) {
           Enseignant enseignant = enseignants.get();
           enseignantRepository.delete(enseignant);
           return ResponseEntity.ok("enseignant with ID " + id + " deleted successfully");
       } else {
           return ResponseEntity.status(HttpStatus.NOT_FOUND).body("enseignant with ID " + id + " not found");
       }
   }
}
