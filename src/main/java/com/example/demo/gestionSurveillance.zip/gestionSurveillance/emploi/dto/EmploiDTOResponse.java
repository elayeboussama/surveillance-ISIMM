package com.example.demo.gestionSurveillance.emploi.dto;

import java.util.Date;

public record EmploiDTOResponse(
        Date dateDebut, Date dateFin
) {
}


